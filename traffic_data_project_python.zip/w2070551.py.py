import csv                  #This part imports the csv file, to read and write the files from the data set where data is stored.
import math                 #This math module immported so that functions such as calculations can be completed
from graphics import *      #The graphics.py libary has been imported so that the graphical representation of the data ouptput can be shown in a histogram.

#Task A. Input Validation (8 marks)  
def get_valid_integer(prompt, min_val, max_val):#In this section a new defined function has been created "Get valid integer" which takes the 3 parameters, prompt, minimum value and maximum value
    while True:
        try:                                    #The minimum and maximum value simply determines a variable to tell the user to 
                        #enter a integer value within a range and if the value entered in the range does not exceed then it will tell you to an enter integer between the values
            value = int(input(prompt))
            if value < min_val or value > max_val:
                print(f"Out of range - values must be in the range {min_val} and {max_val}.")
            else:
                return value
        except ValueError:
            print("Integer required.")              # For instance if a integer is not enetered and a string has been etered the code will automatically tell the user to enter a integer value such a number like "06" and not float values can be enetered.

def get_date():         # In this part a new defined function has been defined which will take the date from the code above and check if the value has been entered between the integers that allowed then it will simply run the code.
    day = get_valid_integer("Please enter the day of the survey in the format dd: ", 1, 31) # eneter a valid date between 1 and 31
    month = get_valid_integer("Please enter the month of the survey in the format MM: ", 1, 12) # enter a value month between 1,12 can only be an integer not a string
    year = get_valid_integer("Please enter the year of the survey in the format YYYY: ", 2000, 2024)# enter a valid year between the two ranges here
    return day, month, year     # once the code is completely running as expected then it will start to take the date and then ouput the right data according to date entered. 
    print() # this simply gives a space before next line of code.
    
def load_new_dataset():
    while True:                     #This code here simply is for section of Part E of the assignments and keep looping asks the user if he would like to load a new dataset.
        choice = input("Would you like to load a new dataset? (Y/N): ").strip().upper() # if the user selects yes then it will run it again if NO then it will end the code.
        if choice == "Y":
            return True # The code .strip() .upper() will take both lower case and upper case when user Y for "yes" and N for "no".
        elif choice == "N":
            return False
        else:
            print("Invalid input. Please enter 'Y' to load a new dataset or 'N' to quit.") # if the user enters N for No it will end the loop
            print()

#Task B. Outcomes (20 marks)  
def load_data(filename):      #defines a new function called load data and the filename which will recognise what name of the file we would like to read from.  
    data = []               #stores the rows of the data wwe will read from each file.
    try:                #this try code will simply just jump straight to the except FILE NOT found error and print rather than crashing if code is not working as expected
        with open(filename, mode='r') as file:      
            reader = csv.DictReader(file)           #These lines of code below will read the filename and will check if the data is valid it will run proceed with outputting the relevenat data
            for row in reader:                      #And if the date is not matched then it will say data file not valid and ask user to try again enter a correct one.
                data.append(row)
    except FileNotFoundError:
        print(f"File {filename} not found. Please check the name and try again.")
    return data


#In this section, the following code has been designed to individually calculate the values as per the requirements, it will calculate requirments according to what has been asked and it will return value if date matches the data 

def count_vehicles(data):           # this function will calculate the total number of vehicles according to date entered and will ouput the results.
    return len(data)

def count_trucks(data):                 #This code will simply check if the data "truck" is visible in the VehicleType column if it is then it will calculate the total of trucks there by filtering the other data out.
    return sum(1 for row in data if row["VehicleType"].strip().lower() == "truck")  #.strip()removes any unecessary spaces and .lower converts the string into lowercase.

def count_electric_vehicles(data):
    return sum(1 for row in data if row["elctricHybrid"].strip().lower() == "true") #this code will simply check if the value "true" is presneted in this column if so it will count total value and return the output.

def count_two_wheeled(data):
    two_wheeled_types = {"bicycle", "motorcycle", "scooter"} #in this line of code I have provided three types of data types its looking for .
    return sum(1 for row in data if row["VehicleType"].strip().lower() in two_wheeled_types) #this code will check and caulcate all three of the two wheeled types and ouput result

def count_northbound_buses(data): # This code defined the function count northbound buses and calculatees and return the total numbers of buses travelling through northbound at the junction
    return sum(1 for row in data if row["JunctionName"] == "Elm Avenue/Rabbit Road" and row["VehicleType"].strip().lower() == "buss" and row["travel_Direction_out"].strip() == "N")
    #The above line also checks if all conditions are met then it adds 1 to the sum 

def count_straight_through(data):
    return sum(1 for row in data if row["travel_Direction_in"].strip() == row["travel_Direction_out"].strip())#Iterates through each row in the data.
#This will also check the total number of vehicles that are travelling straight through a junction
#Compares the "travel_Direction_in" and "travel_Direction_out" fields to check if they are the same (indicating the vehicle traveled straight through without turning).
#Counts the number of vehicles that match this condition using sum(1).
#Returns the total count of vehicles that traveled straight through the junction.

def calculate_truck_percentage(data):
    total_vehicles = count_vehicles(data) #this code stores the result of the total number of vehicles in the variable total_vehicles
    total_trucks = count_trucks(data) # In a similar way this function also call the total trucks to get the total number of trucks and stores it in the variable.
    return math.ceil((total_trucks / total_vehicles) * 100) if total_vehicles > 0 else 0 #math.ceil will round to nearest whole number  and if the total_vehcules is grreater than 0 it will return the calculated percentages

def calculate_avg_bicycles_per_hour(data):
    hourly_bicycle_count = {}#stores the count for bicycles for each hour
    for row in data:#iterates through each row in data 
        if row["VehicleType"].strip().lower() == "bicycle": #This function calculates the average bicycles per hour from the data. It tracks the count of bicycles for each hour in a dictionary,                                                
            hour = int(row["timeOfDay"].split(":")[0])#':' this spilts hour and converts to int
            #updating it as it processes rows where the vehicle type is "bicycle." After summing the total bicycles, it divides the total by 24
            if hour not in hourly_bicycle_count: #to find the average, rounding down to the nearest whole number. If no bicycles are recorded, it returns 0.
                hourly_bicycle_count[hour] = 0 # it initialises count to zero and increments 1 each time
            hourly_bicycle_count[hour] += 1 #increments by each hour and adds on to the total
    total_bicycles = sum(hourly_bicycle_count.values())#adds all values to get total bicycles per hour 
    return math.floor(total_bicycles / 24) if total_bicycles > 0 else 0
#this code above will return the values by calculating all of the hourly bicycle counts

def count_over_speed_limit(data): # This function count over speed limit counts how many vehicles exceeds speed limit and compes to junciton speed limit and if 
    return sum(1 for row in data if int(row["VehicleSpeed"]) > int(row["JunctionSpeedLimit"])) #vheicle speed limit it high it adds one to the total count and returns function

def count_vehicles_per_junction(data, junction_name): # this junction name is the name of junction where the count will be done
    return sum(1 for row in data if row["JunctionName"] == junction_name)
# this code for each row checks if JunctionName matches junction_name and if it is true 1 is added to the total.
#sum function just calulcates it.

def calculate_scooter_percentage(data):
    elm_data = [row for row in data if row["JunctionName"] == "Elm Avenue/Rabbit Road"]
    total_elm = len(elm_data)#calculates the length of elm_data which is a variable created
    total_scooters = sum(1 for row in elm_data if row["VehicleType"].strip().lower() == "scooter")
    return math.floor((total_scooters / total_elm) * 100) if total_elm > 0 else 0 #math.floor will round down the value 

def find_peak_hour(data, junction_name): # I have specified the junction i need the data for busisest hours
    hour_count = {} # Keeps tracks of number of occurences for each hour at the specific jucntion                                
    for row in data: #iterates through each row in the data list
        if row["JunctionName"] == junction_name: #checks if the current rows matches the name given
            hour = int(row["timeOfDay"].split(":")[0]) #Splits the "timeOfDay" takes the first part and converts it to an integer.
            if hour not in hour_count: #if hour is not a dictionary it will initalise it to 0
                hour_count[hour] = 0
            hour_count[hour] += 1#this will increment the count for the hour by 1
    if not hour_count:#if no data was fiund the specific junc return an empty list and count of 0
        return [], 0  # Return empty if no data for the junction
    peak_hour_count = max(hour_count.values()) # this retrieves all of the traffic count from the hour count dictionary
    peak_hours = [hour for hour, count in hour_count.items() if count == peak_hour_count]
    return peak_hours, peak_hour_count#this one will just calculate and return the values
#max finds the maximum value

def count_rainy_hours(data):
    #Count the number of unique hours with rain (light or heavy) in the dataset.
    rainy_hours = set() #this will automatically removes the duplicates
    for row in data:
        # Normalize Weather_Conditions to handle variations
        condition = row["Weather_Conditions"].strip().lower() #converts the uppercase into lowercase and removes any spaces if they are
        if condition in ["heavy rain", "light rain"]: #checks the condition if it is either heavy rain or light rain and if it is then it will check the time of day and acording that it will add the number of hours of rain and output the resu;ts.
            # Extract the hour from timeOfDay
            hour = int(row["timeOfDay"].split(":")[0])#This line extracts timeof dat in the format "HH:MM:SS". the split function
#splits the string into a list where first element [0] is the hour part. The int() function converts this hour string to int.
            rainy_hours.add(hour)#this code will icnrements and add the number of hours and will then display the output.
    return len(rainy_hours)#This will then return the total of hours of rainy hours. 

#Task C. Save Results as a Text File (8 Marks)
def save_results_to_file(results):
    with open("results.txt", "a") as file: # simply saves all of the results on the results.txt file 
        for result in results:
            file.write(result + "\n") #\n will add each on a seperate line 
        file.write("\n")  # Separate different sessions with a newline

# New function to find the highest number of vehicles in an hour on a given junction
def find_max_vehicles_in_hour(data, junction_name="Hanley Highway/Westway"):
    # Create a list to hold the vehicle counts per hour
    hourly_data = [0] * 24  # 24 hours, initialized to 0

    # Loop through the data and count vehicles per hour for the given junction
    for row in data:
        if row["JunctionName"] == junction_name:
            hour = int(row["timeOfDay"].split(":")[0])  # Extract hour from timeOfDay
            hourly_data[hour] += 1  # Increment the count for that hour

    # Return the maximum vehicle count in any hour
    return max(hourly_data)

def extract_hourly_data(data, junction_name):
    hourly_data = [0] * 24  # Initialize a list to hold counts for 24 hours
    for row in data:
        if row["JunctionName"] == junction_name:
            hour = int(row["timeOfDay"].split(":")[0])  # Extract the hour from timeOfDay
            hourly_data[hour] += 1 #increments each time by adding 1 every time
    return hourly_data

def draw_histogram(data_elm, data_hanley, selected_date):
    win = GraphWin("Histogram", 1250, 500)  # this will give the screen size of the graphical display of 1250, 500. 
    win.setBackground("white")  # This simply gives a white background color of the screen on the graphics.py but this can be changed according to the requirements. 

    # Title
    title = Text(Point(300, 30), f"Histogram of Vehicle Frequency per Hour ({selected_date})") #this code just simply shows the date to say that this is the slected date that the histogram has been presented for.
    title.setSize(14)   # this just makes your styling of the writing displayed such as sets a font size of writing and style which in this case is bold
    title.setStyle("bold")
    title.draw(win)#This displays the title on the graphical window when run.

    # Calculate bar dimensions
    bar_width = 15 # This will simply set each of teh width of each bar and they have put thsi in pixels.
    gap = 5         # This will be the spaced between the two bars of each hours
    max_height = 300    # this tells you how maximum height of a bar you can get on the graph
    max_count = max(max(data_elm), max(data_hanley)) # This just find the just

    x_start = 100 #this code sets the initial horizontal positions for drawing bars in histogram. this value
    #then will be used a starting point for the first bar and following bars will be drawn offset
    #by a certain amount using bar width

    for hour in range(24): #The following code will loops through 24 hours to draw bars and labels for each hour.
        # Scale heights based on maximum count
        elm_height = (data_elm[hour] / max_count) * max_height if max_count > 0 else 0          #The following lines of code converts the vehicle counts into pixel height based on the maximum count
        hanley_height = (data_hanley[hour] / max_count) * max_height if max_count > 0 else 0    #The code "IF max_count >0 else 0 will simply set bar height to zero avoid any division by 0

        # Draw Elm Avenue bar
        elm_bar = Rectangle(Point(x_start, 400 - elm_height), Point(x_start + bar_width, 400))#creates a rectangle with its top left and bottom right corners, so the bar grows upwards.
        elm_bar.setFill("red")
        elm_bar.draw(win)    #this will display the bar

        # Draw Hanley Highway bar
        hanley_bar = Rectangle(Point(x_start + bar_width + 1.6, 400 - hanley_height), # for the depth between each of the two bars
                               Point(x_start + 2 * bar_width + gap, 400))
        hanley_bar.setFill("green")    #this will color the bar color green
        hanley_bar.draw(win)           #this will display the bar for hanley bar 

        # Draw hour labels
        hour_label = Text(Point(x_start + bar_width, 420), f"{hour:02d}") # this code will label the each hour 00 to 23 below the bars, an dplaces the label beloe the correcsponding color
        hour_label.setSize(8)
        hour_label.draw(win)#displays the output for hour labels.

        # Display the values on top of the bars
        # Elm Avenue value
        if elm_height > 0:
            elm_value = Text(Point(x_start + (bar_width / 2), 400 - elm_height - 10), str(data_elm[hour])) # The following lines of code in the ELm Avenue will display the vehicle count as text above the ELm Avenue BAr if its height is greater than Zero
            elm_value.setSize(10)           # Point - code will center the text above the bar and offsets it slightly upwards.
            elm_value.setStyle("bold")
            elm_value.draw(win) #Displays the bars that need to be printed and same rule applies to code for the Hanley Highway Value.

        # Hanley Highway value
        if hanley_height > 0:
            hanley_value = Text(Point(x_start + (1.5 * bar_width) + gap, 400 - hanley_height - 10), str(data_hanley[hour])) # The following lines of code in the ELm Avenue will display the vehicle count as text above the ELm Avenue BAr if its height is greater than Zero
            hanley_value.setSize(10)    # Point - code will center the text above the bar and offsets it slightly upwards.
            hanley_value.setStyle("bold")
            hanley_value.draw(win)  #Displays the bars that need to be printed and same rule applies to code for the Hanley Highway Value.

        x_start += 2 * bar_width + gap + 10 #Purpose: Moves the x_start position forward to accommodate the next pair of bars (Elm Avenue and Hanley Highway) and ensure proper spacing between them.

    # Draw legend
    legend_box_elm = Rectangle(Point(50, 50), Point(70, 70))        #The following lines of the code for "Draw legend" simply creates a legend to indicate the meaning of the red and green bars
    legend_box_elm.setFill("red")
    legend_box_elm.draw(win)                                        # The red reactangle indicates the ELM avenue bars, Green rectangle indicates the Hanley Highway, and the labels 
    legend_text_elm = Text(Point(160, 60), "Elm Avenue/Rabbit Road")
    legend_text_elm.setSize(10)
    legend_text_elm.draw(win)

    legend_box_hanley = Rectangle(Point(50, 80), Point(70, 100))    #The following lines of the code for "Draw legend" simply creates a legend to indicate the meaning of the red and green bars
    legend_box_hanley.setFill("green")
    legend_box_hanley.draw(win)                                     # The red reactangle indicates the ELM avenue bars, Green rectangle indicates the Hanley Highway, and the labels
    legend_text_hanley = Text(Point(160, 90), "Hanley Highway/Westway")
    legend_text_hanley.setSize(10)
    legend_text_hanley.draw(win)
    
    x_axis_label = Text(Point(650, 460),"Hours 00:00 to 24:00")  # Adds a label at the bottom of the chart indicating the range of hours e.g "Hours 00:00 to 24:00"
    x_axis_label.setSize(12)
    x_axis_label.draw(win)
    
    win.getMouse()  # Pause the program until the user clikcks on the mouse in order for the graphical windows to close and display the results
    win.close()
    
    
def main():
    while True:
        day, month, year = get_date()   # this checks the date inputted at the start of code and if it meets one of the CSV files that have been linked to this data then it will simply ouput that you have slected the file and it will atemmpt to load it.
        selected_date = f"{day:02d}/{month:02d}.{year}"
        filename = f"traffic_data{day:02d}{month:02d}{year}.csv" #However if the entered date at the start then it wonr run and simply output no data loaded from data where it is stored in the function {filename} and tell you to try again.
        print(f"Attempting to load data from {filename}...")

        data = load_data(filename)
        if not data:    #However if the entered date at the start then it wonr run and simply output no data loaded from data where it is stored in the function {filename} and tell you to try again.
            print(f"No data loaded from {filename}. Please try again.")
            continue

        #If the data file selected matches the CSV file dates then it will instantly ouput the following print statments and it will also append it and save it as text file which has been created "Results.txt".
        
        print()
        #result.append
        results = [] # This is a list of results where all of the results will be ouputted from 
        results.append(f"data file selected is traffic_data{day:02d}/{month:02d}/{year}")   # will output the data file that has been selected
        results.append(f"The total number of vehicles for this date is {count_vehicles(data)}") # Callculates and outputs thet total number of vehicles as per date entered
        results.append(f"The total number of trucks recorded for this date is {count_trucks(data)}") # Callculates and outputs thet total number of trucks recorded as per date entered
        results.append(f"The total number of electric vehicles recorded for this date is {count_electric_vehicles(data)}") # Callculates and outputs thet total number of electric vehicles as per date entered
        results.append(f"The total number of 'Two Wheeled' vehicles recorded for this date is {count_two_wheeled(data)}") # Callculates and outputs thet total number of two wheeeled vehicles as per date entered
        results.append(f"The total number of busses leaving Elm Avenue/Rabbit Road junction heading north is {count_northbound_buses(data)}") # Callculates and outputs thet total number of northbound buses as per date entered
        results.append(f"The total number of vehicles passing through junctions without turning left or right is {count_straight_through(data)}") # Callculates and outputs thet total number of vehicles passing without turning left or right as per date entered
        results.append(f"The percentage of total vehicles recorded that are trucks for this date is {calculate_truck_percentage(data)}%") # Callculates and outputs thet total number of truck percentage as per date entered
        results.append(f"The average number of Bicycles per hour for this date is {calculate_avg_bicycles_per_hour(data)}") # Callculates and outputs thet total number of avergae bicycles per hour as per date entered
        results.append(f"The total number of vehicles over the speed limit for this day is {count_over_speed_limit(data)}") # Callculates and outputs thet total number of vehicles that drove over the speed limit as per date entered
        results.append(f"The total number of vehicles recorded recorded through only Elm Avenue/Rabbit Road junction is {count_vehicles_per_junction(data, 'Elm Avenue/Rabbit Road')}") # Callculates and outputs thet total number of vehicles on Elm Avenue / Rabbit road 
        results.append(f"The total number of vehicles recorded recorded through only Hanley Highway/Westway junction is {count_vehicles_per_junction(data, 'Hanley Highway/Westway')}")# Callculates and outputs thet total number of vehicles on Hanley Highway / Westway jucntion
        results.append(f"{calculate_scooter_percentage(data)}% of vehicles recorded through Elm Avenue/Rabbit Road are scooters ") # Callculates and outputs thet total percentage that are scooters

        # Add the highest number of vehicles in an hour for Hanley Highway/Westway
        max_vehicles = find_max_vehicles_in_hour(data, "Hanley Highway/Westway")    #formula that has been created to calculate find max vehicles in an hour 
        results.append(f"The highest number of vehicles in an hour on Hanley Highway/Westway is: {max_vehicles}")    #outputs the results    

        peak_hours, peak_count = find_peak_hour(data, "Hanley Highway/Westway") # uses a for loop as this data will be required on all dates and checks the hours recorded from start to finish
        for hour in peak_hours:
            results.append(f"The most vehicles through Highway/Westway is recorded between {hour:02d}:00 and {hour + 1:02d}:00")
        results.append(f"The number of hours of rain on this date is {count_rainy_hours(data)}") #This simply just outputs the number of hours of rain on specified date
        
        # Print the results to the console
        for result in results: #outputs the result on the console.
            print(result)

        # Save the results to the file
        save_results_to_file(results) #this is used for text file

        # Extract hourly data for each junction
        data_elm = extract_hourly_data(data, "Elm Avenue/Rabbit Road")
        data_hanley = extract_hourly_data(data, "Hanley Highway/Westway")

        # Draw the histogram
        draw_histogram(data_elm, data_hanley, selected_date) #this code will draw the histogram by extracting the following things

        if not load_new_dataset():
            print("End of run. Goodbye!")   #If the user select N for Not running the program again then it will close the program.
            break

if __name__ == "__main__": #The details of what main() does depend on the code inside it and ouputs the data. 
    main()
#If the script is executed directly, it will call the main() function and execute the code inside it.
#Nothing will happen. The main() function will not be executed because of the if __name__ == "__main__": condition.

"""
##References:
    
Geeks for Geeks - Python Dictionary Methods

    - Helped with the logic for checking and updating dictionary values {lines 6 to 34}
    
    URL: https://wwww.geeksforgeeks.org/python-dictionary

Read the Docs - Python Beginners documentation

    - Used this to understand how to actually Import / Read CSV files {lines 35 to 47}

    URL: https://python-adv-web-apps.readthedocs.io/en/latest/csv.html#reading-from-a-csv

Geeks for Geeks  - File Handling in Python

    - This is used for referecning to understand how to open file and read and append {lines 6 to 34}
    
    URL: https://www.geeksforgeeks.org/how-to-read-from-a-file-in-python/

Python.org Documentation - Working with Lists and Loops (Lines 75 to 80).  

   URL: https://docs.python.org/3/tutorial/datastructures.html  

Real Python - User Defined Functions e.g. Returning values

    - This was used to understand the logical and formation of how returning a function works.

    URL: https://realpython.com/python-return-statement/

ChatGPT 

Explanations for improving code functionality and Histograms (Lines 98-110, 125-130, 232).

[lines 98-110] Had used an AI to fix issue as it was not working. 

Youtube - Understanding Histograms

    - Used Histograms to give a start of it and ChatGPT to fix the remaining errors of it [lines 153 to 229]

    URL: https://www.youtube.com/watch?v=R39vTAj1u_8

Python.org - Documentation – [Functions]

    - defining-functions: Assisted in creating reusable functions (Lines 42-50). 

    URL: https://docs.python.org/3/tutorial/controlflow.html

Real Python – Working with Lists

    -  Referenced for list manipulation and loops (Lines 250-252)

    URL: https://realpython.com/python-lists/


"""
